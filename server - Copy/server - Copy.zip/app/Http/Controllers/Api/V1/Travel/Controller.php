<?php

namespace App\Http\Controllers\Api\V1\Travel;


/**
 * @OA\Info(
 *      title="API Quin Travel",
 *      version="1.0.0"
 * )
 */
abstract class Controller {}
