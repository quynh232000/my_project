<?php

namespace App\Http\Controllers\Admin\Portfolio;

use App\Http\Controllers\AdminController;
use App\Models\Admin\UserModel;
use App\Models\Portfolio\IconModel;
use App\Services\FileService;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class IconController extends AdminController
{
   private $table = null;
    public function __construct(Request $request)
    {
        parent::__construct($request);
        $this->table = new IconModel();
    }
    public function index()
    {
        $query = $this->table->with('creator');
        if(request()->search ?? false){
            $query->where('name','LIKE','%'.request()->search.'%');
        }
        $this->_params['items'] = $query->orderByDesc('id')->paginate(20);
        return view($this->_viewAction, ['params' => $this->_params]);
    }
    public function update(Request $request, $id)
    {
        $item = $this->table->find($id);
        $icon_url           = $request->icon_link ?? $item->icon;
        if($request->hasFile('icon')){
            $fileService    = new FileService();
            $icon_url       = $fileService->uploadFile($request->icon,'portfolio.icon',auth()->id())['url'] ?? '';
        }

        $item->update([
                                'name'          => $request->name,
                                'slug'          => Str::slug($request->name),
                                'icon'          => $icon_url,
                                'updated_at'    => now()

                            ]);
        return redirect()->back()->with('success', ' Update successfully!');
    }
    public function edit($id)
    {
        $this->_params['item']  = $this->table->find($id);
        return view($this->_viewAction, ['params' => $this->_params]);
    }
    public function create()
    {
        return view($this->_viewAction, ['params' => $this->_params]);
    }
    public function store(Request $request)
    {
        $icon_url           = $request->icon_link ?? '';
        if($request->hasFile('icon')){
            $fileService    = new FileService();
            $icon_url       = $fileService->uploadFile($request->icon,'portfolio.icon',auth()->id())['url'] ?? '';
        }

        $this->table->create([
                                'name'          => $request->name,
                                'slug'          => Str::slug($request->name),
                                'icon'          => $icon_url,
                                'created_at'    => now(),
                                'created_by'    => auth()->id(),
                                'status'        => 'active'
                            ]);

        return redirect()->back()->with('success', 'Create successfully.');
    }
    public function destroy($id)
    {
        $this->table->where('id', $id)->delete();
        return redirect()->back()->with('success', 'Delete successfully.');
    }
}
