<?php

namespace App\Models\General;

use Illuminate\Database\Eloquent\Model;

class OrganizationModel extends Model
{
    protected $table = config('constants.table.general.TABLE_ORGANIZATION');
}
