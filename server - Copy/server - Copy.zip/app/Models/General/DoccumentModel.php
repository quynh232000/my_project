<?php

namespace App\Models\General;

use Illuminate\Database\Eloquent\Model;

class DoccumentModel extends Model
{
    protected $table = config('constants.table.general.TABLE_DOCCUMENT');


}
