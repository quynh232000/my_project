php artisan scribe:generate
